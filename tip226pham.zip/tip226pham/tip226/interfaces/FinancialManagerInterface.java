package interfaces;

public interface FinancialManagerInterface {
    void showMenu();
    void viewPropertyData();
    void viewEnterpriseFinancialReport();
}