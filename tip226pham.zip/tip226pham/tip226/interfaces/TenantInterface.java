package interfaces;

public interface TenantInterface {
    void showMenu();
    double checkPaymentStatus();
    void makeRentalPayment();
    void updatePersonalData();
}