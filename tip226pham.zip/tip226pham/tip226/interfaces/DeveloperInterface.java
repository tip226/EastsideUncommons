package interfaces;

public interface DeveloperInterface {
    void showMenu();
    void showPopulateMenu();
    void promptAndPopulate(String tableName);
    void populateAllTables();
}