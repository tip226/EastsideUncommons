package interfaces;

public interface CompanyManagerInterface {
    void showMenu();
    void addNewProperty();
    void generateApartmentsForProperty();
}